﻿#pragma once

#include "MainPage.g.h"
#include <ppl.h>
#include "bass.h"

namespace netradio
{
	public ref class MainPage sealed
	{
	public:
		MainPage();

	private:
		void OpenURL(wchar_t *url);
		void DoMeta();
		void open_Click(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e);
		void timer_Tick(Object^ sender, Object^ e);

		static void CALLBACK MetaSync(HSYNC handle, DWORD channel, DWORD data, void *user);
		static void CALLBACK StallSync(HSYNC handle, DWORD channel, DWORD data, void *user);
		static void CALLBACK EndSync(HSYNC handle, DWORD channel, DWORD data, void *user);
		static void CALLBACK StatusProc(const void *buffer, DWORD length, void *user);

		concurrency::critical_section lock;
		Windows::UI::Xaml::DispatcherTimer timer;
		DWORD req;	// request number/counter
		HSTREAM chan;	// stream handle
	};
}

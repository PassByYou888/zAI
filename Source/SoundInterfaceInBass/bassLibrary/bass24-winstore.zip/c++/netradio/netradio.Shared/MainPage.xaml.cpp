﻿#include "pch.h"
#include "MainPage.xaml.h"

// HLS definitions (copied from BASSHLS.H)
#define BASS_SYNC_HLS_SEGMENT	0x10300
#define BASS_TAG_HLS_EXTINF		0x14000

using namespace netradio;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;
using namespace concurrency;

const wchar_t *urls[10] = { // preset stream URLs
	L"http://stream-dc1.radioparadise.com/rp_192m.ogg", L"http://www.radioparadise.com/m3u/mp3-32.m3u",
	L"http://network.absoluteradio.co.uk/core/audio/mp3/live.pls?service=a8bb", L"http://network.absoluteradio.co.uk/core/audio/aacplus/live.pls?service=a8",
	L"http://somafm.com/secretagent.pls", L"http://somafm.com/secretagent32.pls",
	L"http://somafm.com/suburbsofgoa.pls", L"http://somafm.com/suburbsofgoa32.pls",
	L"http://ai-radio.org/256.ogg", L"http://ai-radio.org/48.aacp"
};

static MainPage^ mainpage; // bit hacky, but there's only one main page right?

// display error messages
static void Error(const wchar_t *es, int ec = 0)
{
	auto messageDialog = ref new Windows::UI::Popups::MessageDialog(ref new String(es) + "\n(error code: " + (ec ? ec : BASS_ErrorGetCode()) + ")");
	messageDialog->ShowAsync();
}


static String^ ANSIString(const char *as)
{
	int n = MultiByteToWideChar(CP_ACP, 0, as, -1, 0, 0);
	wchar_t *ws=new wchar_t[n];
	MultiByteToWideChar(CP_ACP, 0, as, -1, ws, n);
	String^ s=ref new String(ws);
	delete[] ws;
	return s;
}

MainPage::MainPage()
{
	InitializeComponent();
	mainpage = this;
	TimeSpan ts;
	ts.Duration = 500000;
	timer.Interval = ts;
	timer.Tick += ref new EventHandler<Object^>(this, &MainPage::timer_Tick);
}

void MainPage::timer_Tick(Object^ sender, Object^ e)
{
	if (BASS_ChannelIsActive(chan) == BASS_ACTIVE_PLAYING) {
		timer.Stop(); // finished buffering, stop monitoring
		((TextBlock^)FindName(L"status2"))->Text = "playing";
		{ // get the broadcast name and URL
			const char *icy = BASS_ChannelGetTags(chan, BASS_TAG_ICY);
			if (!icy) icy = BASS_ChannelGetTags(chan, BASS_TAG_HTTP); // no ICY tags, try HTTP
			if (icy) {
				for (; *icy; icy += strlen(icy) + 1) {
					if (!_strnicmp(icy, "icy-name:", 9))
						((TextBlock^)FindName(L"status2"))->Text = ANSIString(icy + 9);
					if (!_strnicmp(icy, "icy-url:", 8))
						((TextBlock^)FindName(L"status3"))->Text = ANSIString(icy + 8);
				}
			}
		}
		// get the stream title
		DoMeta();
	} else {
		((TextBlock^)FindName(L"status2"))->Text = "buffering..." + (100 - BASS_StreamGetFilePosition(chan, BASS_FILEPOS_BUFFERING)).ToString() + "%";
	}
}

// update stream title from metadata
void MainPage::DoMeta()
{
	const char *meta = BASS_ChannelGetTags(chan, BASS_TAG_META);
	if (meta) { // got Shoutcast metadata
		const char *p = strstr(meta, "StreamTitle='"); // locate the title
		if (p) {
			const char *p2 = strstr(p, "';"); // locate the end of it
			if (p2) {
				char *t = _strdup(p + 13);
				t[p2 - (p + 13)] = 0;
				((TextBlock^)FindName(L"status1"))->Text = ANSIString(t);
				free(t);
			}
		}
	}
	else {
		meta = BASS_ChannelGetTags(chan, BASS_TAG_OGG);
		if (meta) { // got Icecast/OGG tags
			const char *artist = NULL, *title = NULL, *p = meta;
			for (; *p; p += strlen(p) + 1) {
				if (!_strnicmp(p, "artist=", 7)) // found the artist
					artist = p + 7;
				if (!_strnicmp(p, "title=", 6)) // found the title
					title = p + 6;
			}
			if (title) {
				if (artist)
					((TextBlock^)FindName(L"status1"))->Text = ANSIString(artist) + " - " + ANSIString(title);
				else
					((TextBlock^)FindName(L"status1"))->Text = ANSIString(title);
			}
		} else {
			meta = BASS_ChannelGetTags(chan, BASS_TAG_HLS_EXTINF);
			if (meta) { // got HLS segment info
				const char *p=strchr(meta,',');
				if (p) ((TextBlock^)FindName(L"status1"))->Text = ANSIString(p+1);
			}
		}
	}
}

void CALLBACK MainPage::MetaSync(HSYNC handle, DWORD channel, DWORD data, void *user)
{
	mainpage->Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([]()
	{
		mainpage->DoMeta();
	}));
}

void CALLBACK MainPage::StallSync(HSYNC handle, DWORD channel, DWORD data, void *user)
{
	if (!data) // stalled
		mainpage->Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
			ref new Windows::UI::Core::DispatchedHandler([]()
		{
			mainpage->timer.Start(); // start buffer monitoring
		}));
}

void CALLBACK MainPage::EndSync(HSYNC handle, DWORD channel, DWORD data, void *user)
{
	mainpage->Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([]()
	{
		((TextBlock^)mainpage->FindName(L"status2"))->Text = "not playing";
		((TextBlock^)mainpage->FindName(L"status1"))->Text = "";
		((TextBlock^)mainpage->FindName(L"status3"))->Text = "";
	}));
}

void CALLBACK MainPage::StatusProc(const void *buffer, DWORD length, void *user)
{
	if (buffer && !length && (DWORD)user == mainpage->req) { // got HTTP/ICY tags, and this is still the current request
		mainpage->Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
			ref new Windows::UI::Core::DispatchedHandler([buffer]()
		{
			((TextBlock^)mainpage->FindName(L"status3"))->Text = ANSIString((char*)buffer); // display status
		}));
	}
}

void MainPage::OpenURL(wchar_t *url)
{
	DWORD r;
	lock.lock(); // make sure only 1 thread at a time can do the following
	r = ++req; // increment the request counter for this request
	lock.unlock();
	BASS_StreamFree(chan); // close old stream
	Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([this]()
	{
		((TextBlock^)FindName(L"status2"))->Text = "connecting...";
		((TextBlock^)FindName(L"status1"))->Text = "";
		((TextBlock^)FindName(L"status3"))->Text = "";
	}));
	DWORD c = BASS_StreamCreateURL(url, 0, BASS_STREAM_BLOCK | BASS_STREAM_STATUS | BASS_STREAM_AUTOFREE | BASS_UNICODE, StatusProc, (void*)r); // open URL
	free(url); // free temp URL buffer
	lock.lock();
	if (r != req) { // there is a newer request, discard this stream
		lock.unlock();
		if (c) BASS_StreamFree(c);
		return;
	}
	chan = c; // this is now the current stream
	lock.unlock();
	if (!c) { // failed to open
		int ec = BASS_ErrorGetCode(); // get the error code in this thread
		Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
			ref new Windows::UI::Core::DispatchedHandler([this,ec]()
		{
			((TextBlock^)FindName(L"status2"))->Text = "not playing";
			Error(L"Can't play the stream", ec);
		}));
	} else {
		// start buffer monitoring
		Dispatcher->RunAsync(Windows::UI::Core::CoreDispatcherPriority::Normal,
			ref new Windows::UI::Core::DispatchedHandler([this]()
		{
			timer.Start();
		}));
		// set syncs for stream title updates
		BASS_ChannelSetSync(chan, BASS_SYNC_META, 0, MetaSync, 0); // Shoutcast
		BASS_ChannelSetSync(chan, BASS_SYNC_OGG_CHANGE, 0, MetaSync, 0); // Icecast/OGG
		BASS_ChannelSetSync(chan, BASS_SYNC_HLS_SEGMENT, 0, MetaSync, 0); // HLS
		// set sync for stalling/buffering
		BASS_ChannelSetSync(chan, BASS_SYNC_STALL, 0, StallSync, 0);
		// set sync for end of stream
		BASS_ChannelSetSync(chan, BASS_SYNC_END, 0, EndSync, 0);
		// play it!
		BASS_ChannelPlay(chan,FALSE);
	}
}

void MainPage::open_Click(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
	const wchar_t *url;
	const wchar_t *name = ((Button^)sender)->Name->Data();
	if (!wcscmp(name, L"customopen")) { // play a custom URL
		url = ((TextBox^)FindName(L"customurl"))->Text->Data(); // get the URL
	} else { // play a preset
		int preset = _wtoi(name + 6) - 1; // get preset from button name ("presetX")
		url = urls[preset];
	}
	if (((CheckBox^)FindName(L"proxydirect"))->IsChecked->Value)
		BASS_SetConfigPtr(BASS_CONFIG_NET_PROXY, (void*)NULL); // disable proxy
	else
		BASS_SetConfigPtr(BASS_CONFIG_NET_PROXY, ((TextBox^)FindName(L"proxyurl"))->Text->Data()); // set proxy server
	// open URL asynchronously (so that main thread is free)
	task<void>(create_async([this,url]
	{
		OpenURL(_wcsdup(url));
	}));
}
